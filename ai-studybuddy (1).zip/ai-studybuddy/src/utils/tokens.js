const jwt = require("jsonwebtoken");

const ACCESS_MAX_AGE = 15 * 60 * 1000; // 15 minutes
const REFRESH_MAX_AGE = 7 * 24 * 60 * 60 * 1000; // 7 days

const generateTokens = (userId, role) => {
  const accessToken = jwt.sign({ userId, role }, process.env.JWT_ACCESS_SECRET, {
    expiresIn: "15m",
  });
  const refreshToken = jwt.sign({ userId, role }, process.env.JWT_REFRESH_SECRET, {
    expiresIn: "7d",
  });
  return { accessToken, refreshToken };
};

const cookieOptions = (maxAge) => ({
  httpOnly: true,
  sameSite: "strict",
  secure: process.env.NODE_ENV === "production",
  maxAge,
});

// Store both tokens in HTTP-only cookies
const setAuthCookies = (res, { accessToken, refreshToken }) => {
  res.cookie("accessToken", accessToken, cookieOptions(ACCESS_MAX_AGE));
  res.cookie("refreshToken", refreshToken, cookieOptions(REFRESH_MAX_AGE));
};

const clearAuthCookies = (res) => {
  const base = {
    httpOnly: true,
    sameSite: "strict",
    secure: process.env.NODE_ENV === "production",
  };
  res.clearCookie("accessToken", base);
  res.clearCookie("refreshToken", base);
};

module.exports = { generateTokens, setAuthCookies, clearAuthCookies };
