const fs = require("fs");
const Material = require("../models/Material");
const { askGemini } = require("../utils/gemini");

const path = require("path");
const pdfParse = require("pdf-parse");

// Helper: read uploaded file text (.txt / .md / .pdf)
const readFileText = async (filePath, originalName) => {
  if (path.extname(originalName).toLowerCase() === ".pdf") {
    const data = await pdfParse(fs.readFileSync(filePath));
    return data.text;
  }
  return fs.readFileSync(filePath, "utf-8");
};

// Helper: find a material and make sure the caller may use it.
// Sends the error response itself and returns null if not allowed.
const findOwned = async (req, res) => {
  const material = await Material.findById(req.params.id);
  if (!material) {
    res.status(404).json({ message: "Not found" });
    return null;
  }
  if (req.user.role !== "admin" && material.user.toString() !== req.user.userId) {
    res.status(403).json({ message: "Access denied" });
    return null;
  }
  return material;
};

// Helper: parse JSON returned by Gemini
const parseJson = (raw) => {
  try {
    return JSON.parse(raw.replace(/```json|```/g, "").trim());
  } catch {
    const err = new Error("AI returned an invalid response, please try again");
    err.status = 502;
    throw err;
  }
};

// POST /api/materials/upload
const uploadMaterial = async (req, res) => {
  if (!req.file) return res.status(400).json({ message: "No file uploaded" });

  const { title } = req.body;
  let content;
  try {
    content = await readFileText(req.file.path, req.file.originalname);
  } finally {
    // Clean up file from disk after reading
    fs.unlink(req.file.path, () => {});
  }

  if (!content || !content.trim()) {
    return res.status(400).json({ message: "Could not extract any text from the file" });
  }

  const material = await Material.create({
    user: req.user.userId,
    title: title || req.file.originalname,
    content,
    filename: req.file.originalname,
  });

  res.status(201).json({ message: "Material uploaded", material });
};

// GET /api/materials
const getMaterials = async (req, res) => {
  const filter = req.user.role === "admin" ? {} : { user: req.user.userId };
  const materials = await Material.find(filter).select("-content -flashcards -quiz -studyPlan").sort("-createdAt");
  res.json(materials);
};

// GET /api/materials/:id
const getMaterial = async (req, res) => {
  const material = await findOwned(req, res);
  if (!material) return;

  res.json(material);
};

// DELETE /api/materials/:id
const deleteMaterial = async (req, res) => {
  const material = await findOwned(req, res);
  if (!material) return;

  await material.deleteOne();
  res.json({ message: "Deleted" });
};

// POST /api/materials/:id/summarize
const summarize = async (req, res) => {
  const material = await findOwned(req, res);
  if (!material) return;

  const prompt = `Summarize the following study material clearly and concisely in bullet points:\n\n${material.content}`;
  const summary = await askGemini(prompt);

  material.summary = summary;
  await material.save();

  res.json({ summary });
};

// POST /api/materials/:id/flashcards
const generateFlashcards = async (req, res) => {
  const material = await findOwned(req, res);
  if (!material) return;

  const count = req.body.count || 5;

  const prompt = `
Create ${count} flashcards from the study material below.
Return ONLY valid JSON in this format, no extra text:
[{"question": "...", "answer": "..."}]

Study material:
${material.content}
`;

  const raw = await askGemini(prompt);
  const flashcards = parseJson(raw);

  material.flashcards = flashcards;
  await material.save();

  res.json({ flashcards });
};

// POST /api/materials/:id/quiz
const generateQuiz = async (req, res) => {
  const material = await findOwned(req, res);
  if (!material) return;

  const count = req.body.count || 5;

  const prompt = `
Create ${count} multiple choice quiz questions from the study material below.
Return ONLY valid JSON in this format, no extra text:
[{"question": "...", "options": ["A", "B", "C", "D"], "answer": "A"}]

Study material:
${material.content}
`;

  const raw = await askGemini(prompt);
  const quiz = parseJson(raw);

  material.quiz = quiz;
  await material.save();

  res.json({ quiz });
};

// POST /api/materials/:id/study-plan
const generateStudyPlan = async (req, res) => {
  const material = await findOwned(req, res);
  if (!material) return;

  const { goal, hoursPerDay, days } = req.body;

  const prompt = `
You are a study planner. Based on the study material below, create a personalized ${days || 7}-day study plan.
Student's goal: ${goal || "Understand and retain the material"}
Available study time: ${hoursPerDay || 2} hours per day.

Return a clear day-by-day schedule with topics and activities.

Study material:
${material.content}
`;

  const studyPlan = await askGemini(prompt);

  material.studyPlan = studyPlan;
  await material.save();

  res.json({ studyPlan });
};

module.exports = {
  uploadMaterial,
  getMaterials,
  getMaterial,
  deleteMaterial,
  summarize,
  generateFlashcards,
  generateQuiz,
  generateStudyPlan,
};
