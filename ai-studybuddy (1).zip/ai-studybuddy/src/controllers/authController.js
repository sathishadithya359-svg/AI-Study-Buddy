const jwt = require("jsonwebtoken");
const User = require("../models/User");
const { generateTokens, setAuthCookies, clearAuthCookies } = require("../utils/tokens");

const publicUser = (user) => ({
  id: user._id,
  name: user.name,
  email: user.email,
  role: user.role,
});

// POST /api/auth/register
const register = async (req, res) => {
  const { name, email, password, role } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ message: "name, email and password are required" });
  }
  if (password.length < 6) {
    return res.status(400).json({ message: "Password must be at least 6 characters" });
  }
  if (role && !["student", "admin"].includes(role)) {
    return res.status(400).json({ message: "role must be 'student' or 'admin'" });
  }

  const existing = await User.findOne({ email: email.toLowerCase() });
  if (existing) return res.status(400).json({ message: "Email already in use" });

  const user = await User.create({ name, email, password, role });
  setAuthCookies(res, generateTokens(user._id, user.role));

  res.status(201).json({ message: "Registered successfully", user: publicUser(user) });
};

// POST /api/auth/login
const login = async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ message: "email and password are required" });
  }

  const user = await User.findOne({ email: email.toLowerCase() });
  if (!user || !(await user.matchPassword(password))) {
    return res.status(401).json({ message: "Invalid credentials" });
  }

  setAuthCookies(res, generateTokens(user._id, user.role));

  res.json({ message: "Logged in", user: publicUser(user) });
};

// POST /api/auth/refresh  (reads the refreshToken cookie)
const refresh = async (req, res) => {
  const token = req.cookies.refreshToken;
  if (!token) return res.status(401).json({ message: "No refresh token" });

  try {
    const decoded = jwt.verify(token, process.env.JWT_REFRESH_SECRET);

    // Make sure the user still exists and use their current role
    const user = await User.findById(decoded.userId);
    if (!user) {
      clearAuthCookies(res);
      return res.status(401).json({ message: "User no longer exists" });
    }

    setAuthCookies(res, generateTokens(user._id, user.role));
    res.json({ message: "Tokens refreshed" });
  } catch {
    clearAuthCookies(res);
    return res.status(401).json({ message: "Invalid refresh token" });
  }
};

// POST /api/auth/logout
const logout = (req, res) => {
  clearAuthCookies(res);
  res.json({ message: "Logged out" });
};

module.exports = { register, login, refresh, logout };
