// Creates the first user directly in MongoDB:  npm run seed
require("dotenv").config();
const mongoose = require("mongoose");
const User = require("../src/models/User");

const USER = {
  name: "sathish s",
  email: "sathishadithya359@gmail.com",
  password: "sathishthara143",
  role: "student",
};

(async () => {
  await mongoose.connect(process.env.MONGO_URI);
  const existing = await User.findOne({ email: USER.email });
  if (existing) {
    console.log(`User ${USER.email} already exists - nothing to do.`);
  } else {
    await User.create(USER);
    console.log(`User ${USER.email} created (role: ${USER.role}).`);
  }
  await mongoose.disconnect();
})().catch((err) => {
  console.error(err.message);
  process.exit(1);
});
